package com.assignment.GasStationProducer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GasStationProducerApplicationTests {

	@Test
	void contextLoads() {
	}

}
