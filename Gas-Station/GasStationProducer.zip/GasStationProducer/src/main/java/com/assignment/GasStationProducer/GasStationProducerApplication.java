package com.assignment.GasStationProducer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GasStationProducerApplication {

	public static void main(String[] args) {
		SpringApplication.run(GasStationProducerApplication.class, args);
	}

}
