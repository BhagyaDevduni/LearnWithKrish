package com.assignment.GasStationConsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GasStationConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
