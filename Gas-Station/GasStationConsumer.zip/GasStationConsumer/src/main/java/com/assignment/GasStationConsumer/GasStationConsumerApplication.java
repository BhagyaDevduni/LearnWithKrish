package com.assignment.GasStationConsumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GasStationConsumerApplication {

	public static void main(String[] args) {
		SpringApplication.run(GasStationConsumerApplication.class, args);
	}

}
